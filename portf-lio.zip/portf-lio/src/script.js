// utilizar Figma como ferramenta para planejar projeto
function mudaTema() {
  document.body.classList.toggle("dark");
}
